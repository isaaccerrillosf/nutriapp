<?php /* Carrusel menú móvil para cliente */ ?>
<div class="menu-carrusel-cliente" id="menu-carrusel-cliente">
    <a href="cliente_dashboard.php" class="carrusel-item-cliente"><span class="carrusel-icon-cliente">🏠</span><span class="carrusel-text-cliente">Inicio</span></a>
    <a href="cliente_dieta.php" class="carrusel-item-cliente"><span class="carrusel-icon-cliente">🍽️</span><span class="carrusel-text-cliente">Dieta</span></a>
    <a href="cliente_rutina.php" class="carrusel-item-cliente"><span class="carrusel-icon-cliente">💪</span><span class="carrusel-text-cliente">Rutina</span></a>
    <a href="cliente_resultados.php" class="carrusel-item-cliente"><span class="carrusel-icon-cliente">📊</span><span class="carrusel-text-cliente">Resultados</span></a>
    <a href="logout.php" class="carrusel-item-cliente"><span class="carrusel-icon-cliente">🚪</span><span class="carrusel-text-cliente">Salir</span></a>
</div> 